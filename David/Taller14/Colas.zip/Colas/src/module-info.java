module Colas {
    requires EanCollections;
    requires kotlin.test;
    requires org.junit.jupiter.api;
}